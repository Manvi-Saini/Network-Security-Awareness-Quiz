const startButton = document.getElementById('start-btn');
const nextButton = document.getElementById('next-btn');
const questionContainer = document.getElementById('question-container');
const questionElement = document.getElementById('question');
const answerButtons = document.getElementById('answer-buttons');
const timerElement = document.getElementById('timer');
const timeDisplay = document.getElementById('time');

let shuffledQuestions, currentIndex, timer;

const questions = [
  {
    question: "What does HTTPS stand for?",
    answers: [
      { text: "HyperText Transfer Protocol Secure", correct: true },
      { text: "HyperText Transfer Protocol Simple", correct: false },
      { text: "HyperTerminal Transfer Protocol Secure", correct: false },
      { text: "HyperText Transfer Protocol Smart", correct: false }
    ]
  },
  {
    question: "Which is a common type of cyber attack?",
    answers: [
      { text: "Phishing", correct: true },
      { text: "Swimming", correct: false },
      { text: "Jogging", correct: false },
      { text: "Cooking", correct: false }
    ]
  },
  {
    question: "Firewall is used for?",
    answers: [
      { text: "Filtering network traffic", correct: true },
      { text: "Cooking food", correct: false },
      { text: "Watching movies", correct: false },
      { text: "Editing documents", correct: false }
    ]
  }
];

startButton.addEventListener('click', startQuiz);
nextButton.addEventListener('click', () => {
  currentIndex++;
  setNextQuestion();
});

function startQuiz() {
  startButton.classList.add('hide');
  shuffledQuestions = questions.sort(() => Math.random() - 0.5);
  currentIndex = 0;
  questionContainer.classList.remove('hide');
  setNextQuestion();
  startTimer();
}

function setNextQuestion() {
  resetState();
  showQuestion(shuffledQuestions[currentIndex]);
  resetTimer();
}

function showQuestion(questionObj) {
  questionElement.innerText = questionObj.question;
  questionObj.answers.forEach(ans => {
    const btn = document.createElement('button');
    btn.innerText = ans.text;
    btn.classList.add('button');
    if (ans.correct) btn.dataset.correct = ans.correct;
    btn.addEventListener('click', selectAnswer);
    answerButtons.appendChild(btn);
  });
}

function resetState() {
  clearStatus(document.body);
  nextButton.classList.add('hide');
  while (answerButtons.firstChild) {
    answerButtons.removeChild(answerButtons.firstChild);
  }
}

function selectAnswer(e) {
  const selected = e.target;
  const correct = selected.dataset.correct === "true";
  setStatus(selected, correct);
  Array.from(answerButtons.children).forEach(btn => {
    setStatus(btn, btn.dataset.correct === "true");
  });
  nextButton.classList.remove('hide');
  clearInterval(timer);
}

function setStatus(element, correct) {
  clearStatus(element);
  element.classList.add(correct ? 'correct' : 'wrong');
}

function clearStatus(element) {
  element.classList.remove('correct');
  element.classList.remove('wrong');
}

function startTimer() {
  timerElement.classList.remove('hide');
  let time = 30;
  timeDisplay.innerText = time;
  timer = setInterval(() => {
    time--;
    timeDisplay.innerText = time;
    if (time <= 0) {
      clearInterval(timer);
      nextButton.classList.remove('hide');
    }
  }, 1000);
}

function resetTimer() {
  clearInterval(timer);
  startTimer();
}
